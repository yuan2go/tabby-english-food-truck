# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m22-boundaries.spec.ts >> phone wrong delivery, full reserved plate, cancel/multitouch and short landscape keep real inventory
- Location: e2e/m22-boundaries.spec.ts:11:1

# Error details

```
Error: expect(received).not.toBeNull()

Received: null
```

# Page snapshot

```yaml
- main [ref=e3]:
  - img "英语餐车游戏画面" [ref=e4]
  - generic:
    - generic:
      - button "暂停" [ref=e6] [cursor=pointer]: Ⅱ
      - generic: 无尽营业
      - button "到活动桌" [ref=e7] [cursor=pointer]
    - group "餐车操作":
      - button "客人A·兔兔：拿盘交付，空手重听请求"
      - button "客人B·刺刺：拿盘交付，空手重听请求"
      - button "果汁机苹果入口"
      - button "果汁机杯座"
      - button "▶ 榨成果汁" [ref=e8] [cursor=pointer]
      - button "切换果汁机" [ref=e9] [cursor=pointer]
      - button "请大咪帮忙"
      - button "1号托盘：放入食品或选择整盘"
      - button "2号托盘：放入食品或选择整盘"
      - button "拿苹果"
      - button "拿香蕉"
      - button "拿空杯"
      - button "苹果汁，1号盘"
      - button "香蕉，1号盘"
      - button "苹果，1号盘"
    - button "带作品到活动桌" [ref=e10] [cursor=pointer]
    - button "点请求气泡重听" [ref=e11] [cursor=pointer]:
      - img "苹果"
      - generic [ref=e12]: ♫
    - generic:
      - status: 这一盘备好了 → 带作品到活动桌，或拿盘点朋友
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test';
  2   | import { layoutFor } from '../src/game/layout';
  3   | import { handOver, hot, lesson, startEndless, startStory, state, tap } from './helpers';
  4   | 
  5   | test.use({
  6   |   viewport: { width: 393, height: 665 },
  7   |   deviceScaleFactor: 3,
  8   |   hasTouch: true,
  9   |   isMobile: true,
  10  | });
  11  | test('phone wrong delivery, full reserved plate, cancel/multitouch and short landscape keep real inventory', async ({
  12  |   page,
  13  | }, info) => {
  14  |   await startEndless(page, false);
  15  |   await page.getByRole('button', { name: '暂停', exact: true }).tap();
  16  |   await page.getByRole('button', { name: '设置', exact: true }).tap();
  17  |   await page.getByRole('button', { name: '两位一起招呼' }).tap();
  18  |   await page.getByRole('button', { name: '← 返回', exact: true }).tap();
  19  |   await expect
  20  |     .poll(
  21  |       async () => (await state(page)).orders.filter((order) => order.status === 'waiting').length,
  22  |       {
  23  |         timeout: 15000,
  24  |       },
  25  |     )
  26  |     .toBe(2);
  27  |   await tap(page, 'tray-0');
  28  |   await tap(page, 'tray-0', 26);
  29  |   await tap(page, 'supply-banana');
  30  |   await expect
  31  |     .poll(async () => (await state(page)).items.find((item) => item.product === 'banana')?.location)
  32  |     .toMatch(/^tray:0:/);
  33  |   await handOver(page);
  34  |   expect((await state(page)).attempts.at(-1)?.result).toBe('request-mismatch');
  35  |   const banana = (await state(page)).items[0];
  36  |   if (!banana) throw Error('banana');
  37  |   await page.waitForTimeout(300);
  38  |   await tap(page, `item-${banana.id}`);
  39  |   await page.getByRole('button', { name: '↩ 放回这份', exact: true }).tap();
  40  |   expect((await state(page)).items).toHaveLength(0);
  41  |   await tap(page, 'machine-apple');
  42  |   await tap(page, 'supply-apple');
  43  |   await tap(page, 'start');
  44  |   await tap(page, 'tray-0');
  45  |   await tap(page, 'supply-banana');
  46  |   // Verify a genuinely reserved, occupied tray before the real clock finishes
  47  |   // the drink. An empty tray would merely replay the guest's request.
  48  |   const reserved = await state(page);
  49  |   expect(reserved.machine.status).toBe('processing');
  50  |   expect(reserved.routing.machine?.tray).toBe(0);
  51  |   expect(
  52  |     reserved.items.some((item) => item.product === 'banana' && item.location.startsWith('tray:0:')),
  53  |   ).toBe(true);
  54  |   await handOver(page, 0);
  55  |   const blocked = await state(page);
  56  |   expect(blocked.machine.status).toBe('processing');
  57  |   expect(blocked.attempts).toEqual(reserved.attempts);
  58  |   expect(blocked.items).toEqual(reserved.items);
  59  |   expect(blocked.orders).toEqual(reserved.orders);
  60  |   await expect(page.getByRole('status')).toContainText('这只盘正等机器的成品');
  61  |   await tap(page, 'supply-apple');
  62  |   const full = await state(page);
> 63  |   expect(full.routing.machine).not.toBeNull();
      |                                    ^ Error: expect(received).not.toBeNull()
  64  |   await tap(page, 'supply-apple');
  65  |   const stillFull = await state(page);
  66  |   expect(stillFull.nextId).toBe(full.nextId);
  67  |   expect(stillFull.items.every((item) => full.items.some((prior) => prior.id === item.id))).toBe(
  68  |     true,
  69  |   );
  70  |   if (stillFull.machine.status === 'empty') {
  71  |     const cup = full.items.find((item) => item.location === 'machine:cup');
  72  |     const apple = full.items.find((item) => item.location === 'machine:apple');
  73  |     expect(stillFull.items.find((item) => item.id === cup?.id)).toMatchObject({
  74  |       product: 'juice',
  75  |       location: 'tray:0:0',
  76  |     });
  77  |     expect(stillFull.items.some((item) => item.id === apple?.id)).toBe(false);
  78  |   } else expect(stillFull.items).toEqual(full.items);
  79  |   await page.getByRole('button', { name: '暂停', exact: true }).tap();
  80  |   const frozen = await state(page);
  81  |   await page.reload();
  82  |   await page.locator('.yard-endless .entry-main').tap();
  83  |   await page.getByRole('button', { name: '开门 / 继续营业' }).tap();
  84  |   await lesson(page);
  85  |   const restored = await state(page);
  86  |   const consumed = frozen.items.find((i) => i.location === 'machine:apple');
  87  |   const vessel = frozen.items.find((i) => i.location === 'machine:cup' || i.product === 'juice');
  88  |   const alreadyFinished = restored.items.some((i) => i.product === 'juice');
  89  |   expect(restored.items.map((i) => i.id)).toEqual(
  90  |     frozen.items.filter((i) => !alreadyFinished || i.id !== consumed?.id).map((i) => i.id),
  91  |   );
  92  |   for (const item of frozen.items.filter((i) => !i.location.startsWith('machine:')))
  93  |     expect(restored.items.find((i) => i.id === item.id)).toEqual(item);
  94  |   if (alreadyFinished)
  95  |     expect(restored.items.find((i) => i.product === 'juice')?.id).toBe(vessel?.id);
  96  |   await expect
  97  |     .poll(
  98  |       async () =>
  99  |         (await state(page)).items.some((i) => i.product === 'juice' && i.location === 'tray:0:0'),
  100 |       { timeout: 15000 },
  101 |     )
  102 |     .toBe(true);
  103 |   const juice = (await state(page)).items.find((i) => i.product === 'juice');
  104 |   if (!juice) throw Error('juice');
  105 |   await tap(page, `item-${juice.id}`);
  106 |   await page.getByRole('button', { name: '收起成品', exact: true }).tap();
  107 |   await page.getByRole('button', { name: '确认收起', exact: true }).tap();
  108 |   expect((await state(page)).recycle?.id).toBe(juice.id);
  109 |   await page.getByRole('button', { name: '↶ 恢复成品', exact: true }).tap();
  110 |   expect((await state(page)).items.find((i) => i.id === juice.id)?.product).toBe('juice');
  111 |   const before = await state(page);
  112 |   const point = await hot(page, 'supply-apple');
  113 |   if (test.info().project.use.browserName !== 'webkit') {
  114 |     const cdp = await page.context().newCDPSession(page);
  115 |     await cdp.send('Input.dispatchTouchEvent', {
  116 |       type: 'touchStart',
  117 |       touchPoints: [{ ...point, id: 1 }],
  118 |     });
  119 |     await cdp.send('Input.dispatchTouchEvent', {
  120 |       type: 'touchStart',
  121 |       touchPoints: [
  122 |         { ...point, id: 1 },
  123 |         { x: point.x + 30, y: point.y, id: 2 },
  124 |       ],
  125 |     });
  126 |     await cdp.send('Input.dispatchTouchEvent', { type: 'touchCancel', touchPoints: [] });
  127 |     await cdp.detach();
  128 |     expect((await state(page)).items).toEqual(before.items);
  129 |   }
  130 |   for (const height of [300, 342, 393]) {
  131 |     await page.setViewportSize({ width: 852, height });
  132 |     const helper = layoutFor(852, height, 'service').helper;
  133 |     await expect
  134 |       .poll(async () => {
  135 |         const point = await hot(page, 'note');
  136 |         return [Math.round(point.x), Math.round(point.y)];
  137 |       })
  138 |       .toEqual([Math.round(helper.x), Math.round(helper.y - 20)]);
  139 |     await expect
  140 |       .poll(async () => {
  141 |         const p = await hot(page, 'note');
  142 |         return page.evaluate((p) => document.elementFromPoint(p.x, p.y)?.tagName, p);
  143 |       })
  144 |       .toBe('CANVAS');
  145 |     await tap(page, 'note');
  146 |     await expect(page.getByRole('heading', { name: '大咪陪你一起做' })).toBeVisible();
  147 |     await page.getByRole('button', { name: '继续营业', exact: true }).tap();
  148 |     await tap(page, 'tray-1', 25);
  149 |     await tap(page, 'supply-apple');
  150 |     const added = (await state(page)).items.find((i) => i.location.startsWith('tray:1:'));
  151 |     expect(added?.product).toBe('apple');
  152 |     if (!added) throw Error('second tray');
  153 |     await page.waitForTimeout(300);
  154 |     await tap(page, `item-${added.id}`);
  155 |     await page.getByRole('button', { name: '↩ 放回这份' }).tap();
  156 |     await page.screenshot({ path: info.outputPath(`short-landscape-${height}.png`) });
  157 |   }
  158 | });
  159 | test('audio loading failure exposes correct retry, never blocks supplies or creates a language error', async ({
  160 |   page,
  161 | }, info) => {
  162 |   await page.route('**/audio/*.wav*', (r) => r.abort());
  163 |   await startStory(page);
```